// pages/canvas/canvas.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    score:0,
    maxScore:100
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    const ctx = wx.createCanvasContext('canvases')
    /**
     * 填充颜色
     */
    ctx.setFillStyle("pink")
    /**
     * 第一个值为x
     * 第二个值为y
     * 第三个值为宽
     * 第四个值为高
     */
    ctx.fillRect(10,10,150,75)
    ctx.draw()
  },
})