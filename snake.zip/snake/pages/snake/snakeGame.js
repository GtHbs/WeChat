// pages/snake/snakeGame.js
Page({
  data: {
    score:0,
    maxScore:100,
    startX:0, //触摸开始的横坐标
    startY:0, //触摸开始的纵坐标
    endX:0,
    endY:0,
    ground:[],  //存储行和列数
    rows:28,    //行数
    cols:20     //列数
  },
  /**
   * 初始化运行模板
   */
  initGround:function(rows,cols) {
    for(var i = 0;i < rows; ++i) {
      var arr = [];
      this.data.ground.push(arr);
      for(var j = 0; j < cols; ++j) {
        this.data.ground[j].push(0);
      }
    }
  },

  onLoad: function (options) {
    this.initGround(this.data.rows,this.data.cols);
  },
  /**
   * 触摸开始的函数
   */
  tapStart:function(event) {
    this.setData({
      startX:event.touches[0].clientX,
      startY:event.touches[0].clientY
    });
  },
  /**
   * 触摸移动
   * @param {}} event 
   */
  tapMove:function(event) {
    this.setData({
      endX:event.touches[0].pageX,
      endY:event.touches[0].pageY
    });
  },
  /**
   * 手指触摸结束
   * @param {*} event 
   */
  tapEnd:function(event) {
    var row = this.data.endX > 0 ? (this.data.endX - this.data.startX) : 0;
    var column = this.data.endY > 0 ? (this.data.endY - this.data.startY) : 0;
    if(Math.abs(row) > Math.abs(column) && row > 0) {
      console.log("向右滑动");
    } else if(Math.abs(row) > Math.abs(column) && row < 0) {
      console.log("向左滑动");
    } else if(Math.abs(row) < Math.abs(column) && column > 0) {
      console.log("向下滑动");
    } else if(Math.abs(row) < Math.abs(column) && column < 0) {
      console.log("向上滑动");
    } else {
      console.log("点击未滑动");
    }
  },
  onReady: function () {},
  onShow: function () {},
  onHide: function () {},
  onUnload: function () {},
  onPullDownRefresh: function () {},
  onReachBottom: function () {},
  onShareAppMessage: function () {}
})